
package MashuduPoe1;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserSignupTest {

    private UserSignup user;

    public UserSignupTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {

        user = new UserSignup();

        user.name = "Mashudu";
        user.familyName = "Nedzi";
        user.userName = "M_01";
        user.passCode = "Password1!";
        user.phoneNumber = "+27838968976";
    }

    @After
    public void tearDown() {
    }

    // ==========================================
    // PART 1: USERNAME TESTS
    // ==========================================

    @Test
    public void testUserNameIsCorrectlyFormatted() {
        assertTrue(UserSignin.checkUserName("M_01"));
    }

    @Test
    public void testUserNameIsIncorrectlyFormatted() {
        assertFalse(UserSignin.checkUserName("Mashudu"));
    }

    @Test
    public void testUserNameWithoutUnderscore() {
        assertFalse(UserSignin.checkUserName("M001"));
    }

    @Test
    public void testUserNameExceedsFiveCharacters() {
        assertFalse(UserSignin.checkUserName("Mash_01"));
    }

    // ==========================================
    // PART 1: PASSWORD TESTS
    // ==========================================

    @Test
    public void testPasswordComplexityIsCorrect() {
        assertTrue(
                UserSignin.checkPasswordComplexity("Password1!")
        );
    }

    @Test
    public void testPasswordComplexityIsIncorrect() {
        assertFalse(
                UserSignin.checkPasswordComplexity("password")
        );
    }

    @Test
    public void testPasswordWithoutCapitalLetter() {
        assertFalse(
                UserSignin.checkPasswordComplexity("password1!")
        );
    }

    @Test
    public void testPasswordWithoutNumber() {
        assertFalse(
                UserSignin.checkPasswordComplexity("Password!")
        );
    }

    @Test
    public void testPasswordWithoutSpecialCharacter() {
        assertFalse(
                UserSignin.checkPasswordComplexity("Password123")
        );
    }

    @Test
    public void testPasswordTooShort() {
        assertFalse(
                UserSignin.checkPasswordComplexity("Pa1!")
        );
    }

    // ==========================================
    // PART 1: CELLPHONE TESTS
    // ==========================================

    @Test
    public void testCellPhoneNumberIsCorrectlyFormatted() {
        assertTrue(
                UserSignin.checkCellPhoneNumber("+27838968976")
        );
    }

    @Test
    public void testCellPhoneNumberIsIncorrectlyFormatted() {
        assertFalse(
                UserSignin.checkCellPhoneNumber("0838968976")
        );
    }

    @Test
    public void testCellPhoneNumberWithWrongCountryCode() {
        assertFalse(
                UserSignin.checkCellPhoneNumber("+19876543210")
        );
    }

    // ==========================================
    // PART 1: SIGNUP TESTS
    // ==========================================

    @Test
    public void testSignupUserSuccessful() {

        String result = UserSignin.signupUser(user);

        assertEquals("Signup was successful!", result);
    }

    @Test
    public void testSignupUserWithIncorrectUsername() {

        user.userName = "Mashudu";

        String result = UserSignin.signupUser(user);

        assertEquals(
                "Username is not correctly formatted; "
                + "please ensure that your username contains "
                + "an underscore and is no more than five "
                + "characters in length.",
                result
        );
    }

    @Test
    public void testSignupUserWithIncorrectPassword() {

        user.passCode = "password";

        String result = UserSignin.signupUser(user);

        assertEquals(
                "Password is not correctly formatted; "
                + "please ensure that the password contains "
                + "at least eight characters, a capital letter, "
                + "a number, and a special character.",
                result
        );
    }

    @Test
    public void testSignupUserWithIncorrectCellNumber() {

        user.phoneNumber = "0838968976";

        String result = UserSignin.signupUser(user);

        assertEquals(
                "Cell number is incorrectly formatted or does "
                + "not contain an international code; "
                + "please correct the number and try again.",
                result
        );
    }

    // ==========================================
    // PART 1: SIGNIN TESTS
    // ==========================================

    @Test
    public void testSigninStatusSuccessful() {

        String result =
                UserSignin.returnSigninStatus(user, true);

        assertEquals(
                "Welcome Mashudu, Nedzi it is great to see you again.",
                result
        );
    }

    @Test
    public void testSigninStatusUnsuccessful() {

        String result =
                UserSignin.returnSigninStatus(user, false);

        assertEquals(
                "Username or password incorrect, please try again.",
                result
        );
    }

    @Test
    public void testSigninWithCorrectDetails() {

        String signinInput =
                user.userName + "\n"
                + user.passCode + "\n";

        InputStream originalInput = System.in;

        try {
            System.setIn(new ByteArrayInputStream(
                    signinInput.getBytes()));

            Scanner input = new Scanner(System.in);

            boolean result = UserSignin.signinUser(user, input);

            assertTrue(result);

            input.close();

        } finally {
            System.setIn(originalInput);
        }
    }

    @Test
    public void testSigninRetriesAfterIncorrectDetails() {

        String signinInput =
                "wrong\nwrong\n"
                + user.userName + "\n"
                + user.passCode + "\n";

        InputStream originalInput = System.in;

        try {
            System.setIn(new ByteArrayInputStream(
                    signinInput.getBytes()));

            Scanner input = new Scanner(System.in);

            boolean result = UserSignin.signinUser(user, input);

            assertTrue(result);

            input.close();

        } finally {
            System.setIn(originalInput);
        }
    }

    // ==========================================
    // PART 2: MESSAGE ID TESTS
    // ==========================================

    @Test
    public void testMessageIDContainsTenDigits() {

        Message message = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?",
                0
        );

        assertTrue(message.checkMessageID());
    }

    // ==========================================
    // PART 2: RECIPIENT TESTS
    // ==========================================

    @Test
    public void testInternationalRecipientIsValid() {

        Message message = new Message(
                "+27718693002",
                "Hello there",
                0
        );

        assertTrue(message.checkRecipientCell());
    }

    @Test
    public void testLocalRecipientFromPoeIsValid() {

        Message message = new Message(
                "08575975889",
                "Hi Keegan, did you receive the payment?",
                1
        );

        assertTrue(message.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipientIsRejected() {

        Message message = new Message(
                "12345",
                "Hello there",
                0
        );

        assertFalse(message.checkRecipientCell());
    }

    // ==========================================
    // PART 2: MESSAGE HASH TESTS
    // ==========================================

    @Test
    public void testMessageHashFormat() {

        Message message = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?",
                0
        );

        String hash = message.createMessageHash();

        assertTrue(
                "Hash should contain two ID digits, message number "
                + "and the first and last words.",
                hash.matches("[0-9]{2}:0:HITONIGHT")
        );
    }

    @Test
    public void testMessageHashUsesUppercase() {

        Message message = new Message(
                "+27718693002",
                "hello everyone",
                1
        );

        String hash = message.createMessageHash();

        assertTrue(hash.endsWith("HELLOEVERYONE"));
    }

    // ==========================================
    // PART 2: SEND MESSAGE TESTS
    // ==========================================

    @Test
    public void testSentMessageSuccessfully() {

        Message message = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?",
                0
        );

        Scanner input = new Scanner(
                new ByteArrayInputStream("1\n".getBytes())
        );

        String result = message.SentMessage(input);

        assertEquals("Message successfully sent", result);
        assertTrue(message.printMessages().contains("Status: Sent"));

        input.close();
    }

    @Test
    public void testMessageDisregarded() {

        Message message = new Message(
                "+27718693002",
                "This message will be disregarded.",
                0
        );

        Scanner input = new Scanner(
                new ByteArrayInputStream("2\n".getBytes())
        );

        String result = message.SentMessage(input);

        assertEquals("Press 0 to delete the message", result);

        assertTrue(
                message.printMessages().contains("Status: Disregarded")
        );

        input.close();
    }

    @Test
    public void testMessageStored() {

        Message message = new Message(
                "+27718693002",
                "This message will be stored.",
                0
        );

        Scanner input = new Scanner(
                new ByteArrayInputStream("3\n".getBytes())
        );

        String result = message.SentMessage(input);

        assertEquals("Message successfully stored", result);

        assertTrue(
                message.printMessages().contains("Status: Stored")
        );

        input.close();
    }

    @Test
    public void testInvalidMessageOptionIsRejected() {

        Message message = new Message(
                "+27718693002",
                "Testing invalid options",
                0
        );

        Scanner input = new Scanner(
                new ByteArrayInputStream("9\n1\n".getBytes())
        );

        String result = message.SentMessage(input);

        assertEquals("Message successfully sent", result);

        input.close();
    }

    // ==========================================
    // PART 2: PRINT MESSAGE TEST
    // ==========================================

    @Test
    public void testPrintMessagesContainsDetails() {

        Message message = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?",
                0
        );

        String result = message.printMessages();

        assertTrue(result.contains("Message ID:"));
        assertTrue(result.contains("Message Hash:"));
        assertTrue(result.contains("Recipient: +27718693002"));
        assertTrue(result.contains(
                "Message: Hi Mike, can you join us for dinner tonight?"
        ));
        assertTrue(result.contains("Status: Pending"));
    }

    // ==========================================
    // PART 2: TOTAL MESSAGE METHOD TEST
    // ==========================================

    @Test
    public void testTotalMessageMethodsReturnSameValue() {

        Message message = new Message(
                "+27718693002",
                "Testing total message methods",
                0
        );

        assertEquals(
                message.returnTotalMessages(),
                message.returnTotalMessagess()
        );
    }

    // ==========================================
    // INTEGRATION TEST: SIGNUP AND SIGNIN
    // ==========================================

    @Test
    public void testSignupAndSigninIntegration() {

        String signupResult = UserSignin.signupUser(user);

        assertEquals("Signup was successful!", signupResult);

        String signinInput =
                user.userName + "\n"
                + user.passCode + "\n";

        InputStream originalInput = System.in;

        try {
            System.setIn(new ByteArrayInputStream(
                    signinInput.getBytes()));

            Scanner input = new Scanner(System.in);

            boolean signinResult =
                    UserSignin.signinUser(user, input);

            assertTrue(signinResult);

            input.close();

        } finally {
            System.setIn(originalInput);
        }
    }
}
