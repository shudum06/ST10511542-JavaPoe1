package MashuduPoe1;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class UserSignupTest {

    private UserSignup user;

    public UserSignupTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {

        user = new UserSignup();

        user.name = "Mashudu";
        user.familyName = "Nedzi";
        user.userName = "M_01";
        user.passCode = "Password1!";
        user.phoneNumber = "+27838968976";
    }

    @After
    public void tearDown() {
    }

    // ==========================================
    // USERNAME TESTS
    // ==========================================

    @Test
    public void testUserNameIsCorrectlyFormatted() {

        assertTrue(UserSignin.checkUserName("M_01"));
    }

    @Test
    public void testUserNameIsIncorrectlyFormatted() {

        assertFalse(UserSignin.checkUserName("Mashudu"));
    }

    // ==========================================
    // PASSWORD TESTS
    // ==========================================

    @Test
    public void testPasswordComplexityIsCorrect() {

        assertTrue(
                UserSignin.checkPasswordComplexity("Password1!")
        );
    }

    @Test
    public void testPasswordComplexityIsIncorrect() {

        assertFalse(
                UserSignin.checkPasswordComplexity("password")
        );
    }

    // ==========================================
    // CELLPHONE TESTS
    // ==========================================

    @Test
    public void testCellPhoneNumberIsCorrectlyFormatted() {

        assertTrue(
                UserSignin.checkCellPhoneNumber("+27838968976")
        );
    }

    @Test
    public void testCellPhoneNumberIsIncorrectlyFormatted() {

        assertFalse(
                UserSignin.checkCellPhoneNumber("0838968976")
        );
    }

    // ==========================================
    // SIGNUP TESTS
    // ==========================================

    @Test
    public void testSignupUserSuccessful() {

        String result = UserSignin.signupUser(user);

        assertEquals(
                "Signup was successful!",
                result
        );
    }

    @Test
    public void testSignupUserWithIncorrectUsername() {

        user.userName = "Mashudu";

        String result = UserSignin.signupUser(user);

        assertEquals(
                "Username is not correctly formatted; "
                + "please ensure that your username contains "
                + "an underscore and is no more than five "
                + "characters in length.",
                result
        );
    }

    @Test
    public void testSignupUserWithIncorrectPassword() {

        user.passCode = "password";

        String result = UserSignin.signupUser(user);

        assertEquals(
                "Password is not correctly formatted; "
                + "please ensure that the password contains "
                + "at least eight characters, a capital letter, "
                + "a number, and a special character.",
                result
        );
    }

    @Test
    public void testSignupUserWithIncorrectCellNumber() {

        user.phoneNumber = "0838968976";

        String result = UserSignin.signupUser(user);

        assertEquals(
                "Cell number is incorrectly formatted or does "
                + "not contain an international code; "
                + "please correct the number and try again.",
                result
        );
    }

    // ==========================================
    // SIGNIN TESTS
    // ==========================================

    @Test
    public void testSigninStatusSuccessful() {

        String result =
                UserSignin.returnSigninStatus(user, true);

        assertEquals(
                "Welcome Mashudu, Nedzi it is great to see you again.",
                result
        );
    }

    @Test
    public void testSigninStatusUnsuccessful() {

        String result =
                UserSignin.returnSigninStatus(user, false);

        assertEquals(
                "Username or password incorrect, please try again.",
                result
        );
    }

    // ==========================================
    // INTEGRATION TEST
    // ==========================================

    @Test
    public void testSignupAndSigninIntegration() {

        // First test the signup process

        String signupResult =
                UserSignin.signupUser(user);

        assertEquals(
                "Signup was successful!",
                signupResult
        );

        // Simulate entering the registered username
        // and password during signin

        String signinInput =
                user.userName + "\n"
                + user.passCode + "\n";

        InputStream originalInput = System.in;

        try {

            System.setIn(
                    new ByteArrayInputStream(
                            signinInput.getBytes()
                    )
            );

            Scanner input = new Scanner(System.in);

            boolean signinResult =
                    UserSignin.signinUser(user, input);

            assertTrue(signinResult);

            input.close();

        } finally {

            System.setIn(originalInput);
        }
    }
}