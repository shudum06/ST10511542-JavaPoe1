package MashuduPoe1;

import java.util.Scanner;

public class UserSignup {

    // Variables
    String name;
    String familyName;
    String userName;
    String passCode;
    String phoneNumber;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        UserSignup user = new UserSignup();

        // NAME AND FAMILY NAME

        System.out.print("Enter your name: ");
        user.name = input.nextLine();

        System.out.print("Enter your family name: ");
        user.familyName = input.nextLine();

        // USERNAME

        while (true) {

            System.out.print("Enter your username: ");
            user.userName = input.nextLine();

            if (UserSignin.checkUserName(user.userName)) {

                System.out.println("Username successfully captured.");
                break;

            } else {

                System.out.println(
                    "Username is not correctly formatted; "
                    + "please ensure that your username contains "
                    + "an underscore and is no more than five "
                    + "characters in length."
                );
            }
        }

        // PASSWORD

        while (true) {

            System.out.print("Enter your password: ");
            user.passCode = input.nextLine();

            if (UserSignin.checkPasswordComplexity(user.passCode)) {

                System.out.println("Password successfully captured.");
                break;

            } else {

                System.out.println(
                    "Password is not correctly formatted; "
                    + "please ensure that the password contains "
                    + "at least eight characters, a capital letter, "
                    + "a number, and a special character."
                );
            }
        }

        // CELLPHONE NUMBER

        while (true) {

            System.out.print("Enter your cellphone number: ");
            user.phoneNumber = input.nextLine();

            if (UserSignin.checkCellPhoneNumber(user.phoneNumber)) {

                System.out.println("Cell number successfully captured.");
                break;

            } else {

                System.out.println(
                    "Cell number is incorrectly formatted or does "
                    + "not contain an international code; "
                    + "please correct the number and try again."
                );
            }
        }

        // SIGNUP

        System.out.println("\n" + UserSignin.signupUser(user));

        // SIGNIN

        UserSignin.signinUser(user, input);

        input.close();
    }
}