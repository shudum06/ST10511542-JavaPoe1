package MashuduPoe1;

import java.util.Scanner;

public class UserSignin {

    // CHECK USERNAME

    public static boolean checkUserName(String userName) {

        return userName.contains("_")
                && userName.length() <= 5;
    }

    // CHECK PASSWORD COMPLEXITY

    public static boolean checkPasswordComplexity(String passCode) {

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        if (passCode.length() < 8) {
            return false;
        }

        for (int i = 0; i < passCode.length(); i++) {

            char character = passCode.charAt(i);

            if (Character.isUpperCase(character)) {
                hasCapital = true;
            }

            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                hasSpecialCharacter = true;
            }
        }

        return hasCapital
                && hasNumber
                && hasSpecialCharacter;
    }

    // CHECK CELLPHONE NUMBER

    public static boolean checkCellPhoneNumber(String phoneNumber) {

        /*
         * South African international format:
         * +27 followed by 9 digits
         *
         * Example:
         * +27838968976
         */

        return phoneNumber.matches("^\\+27[6-8][0-9]{8}$");
    }

    // SIGNUP USER

    public static String signupUser(UserSignup user) {

        if (!checkUserName(user.userName)) {

            return "Username is not correctly formatted; "
                    + "please ensure that your username contains "
                    + "an underscore and is no more than five "
                    + "characters in length.";
        }

        if (!checkPasswordComplexity(user.passCode)) {

            return "Password is not correctly formatted; "
                    + "please ensure that the password contains "
                    + "at least eight characters, a capital letter, "
                    + "a number, and a special character.";
        }

        if (!checkCellPhoneNumber(user.phoneNumber)) {

            return "Cell number is incorrectly formatted or does "
                    + "not contain an international code; "
                    + "please correct the number and try again.";
        }

        return "Signup was successful!";
    }

    // SIGNIN USER

    public static boolean signinUser(
            UserSignup user,
            Scanner input) {

        boolean signinSuccessful = false;

        System.out.println("SIGNIN STEP");

        // Keep asking until correct details are entered

        while (!signinSuccessful) {

            System.out.print("Enter your username: ");
            String enteredUserName = input.nextLine();

            System.out.print("Enter your password: ");
            String enteredPassCode = input.nextLine();

            // Compare entered details with signup details

            if (enteredUserName.equals(user.userName)
                    && enteredPassCode.equals(user.passCode)) {

                signinSuccessful = true;

                System.out.println(
                        "\n" + returnSigninStatus(user, true));

            } else {

                System.out.println(
                        "\n" + returnSigninStatus(user, false));

                System.out.println("Please try again.\n");
            }
        }

        return signinSuccessful;
    }

    // RETURN SIGNIN STATUS

    public static String returnSigninStatus(
            UserSignup user,
            boolean signinSuccessful) {

        if (signinSuccessful) {

            return "Welcome "
                    + user.name
                    + ", "
                    + user.familyName
                    + " it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}
