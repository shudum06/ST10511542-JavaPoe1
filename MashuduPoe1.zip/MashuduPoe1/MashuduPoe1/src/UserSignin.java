
package MashuduPoe1;

import java.util.Scanner;

public class UserSignin {

    // CHECK USERNAME
    public static boolean checkUserName(String userName) {

        return userName != null
                && userName.contains("_")
                && userName.length() <= 5;
    }

    // CHECK PASSWORD COMPLEXITY
    public static boolean checkPasswordComplexity(String passCode) {

        if (passCode == null || passCode.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < passCode.length(); i++) {

            char character = passCode.charAt(i);

            if (Character.isUpperCase(character)) {
                hasCapital = true;
            }

            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                hasSpecialCharacter = true;
            }
        }

        return hasCapital && hasNumber && hasSpecialCharacter;
    }

    // CHECK SOUTH AFRICAN INTERNATIONAL CELLPHONE NUMBER
    public static boolean checkCellPhoneNumber(String phoneNumber) {

        return phoneNumber != null
                && phoneNumber.matches("\\+27[6-8][0-9]{8}");
    }

    // REGISTER USER
    public static String signupUser(UserSignup user) {

        if (!checkUserName(user.userName)) {
            return "Username is not correctly formatted; "
                    + "please ensure that your username contains "
                    + "an underscore and is no more than five "
                    + "characters in length.";
        }

        if (!checkPasswordComplexity(user.passCode)) {
            return "Password is not correctly formatted; "
                    + "please ensure that the password contains "
                    + "at least eight characters, a capital letter, "
                    + "a number, and a special character.";
        }

        if (!checkCellPhoneNumber(user.phoneNumber)) {
            return "Cell number is incorrectly formatted or does "
                    + "not contain an international code; "
                    + "please correct the number and try again.";
        }

        return "Signup was successful!";
    }

    // SIGN IN
    public static boolean signinUser(
            UserSignup user, Scanner input) {

        System.out.println("\nSIGNIN STEP");

        while (true) {

            System.out.print("Enter your username: ");
            String enteredUserName = input.nextLine();

            System.out.print("Enter your password: ");
            String enteredPassCode = input.nextLine();

            if (enteredUserName.equals(user.userName)
                    && enteredPassCode.equals(user.passCode)) {

                System.out.println(
                        "\n" + returnSigninStatus(user, true));

                return true;

            } else {

                System.out.println(
                        "\n" + returnSigninStatus(user, false));

                System.out.println("Please try again.\n");
            }
        }
    }

    // RETURN SIGN IN STATUS
    public static String returnSigninStatus(
            UserSignup user, boolean signinSuccessful) {

        if (signinSuccessful) {
            return "Welcome "
                    + user.name
                    + ", "
                    + user.familyName
                    + " it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }
}
